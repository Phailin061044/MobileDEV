module.exports = {
    secret:"phailin-secret-key"
}