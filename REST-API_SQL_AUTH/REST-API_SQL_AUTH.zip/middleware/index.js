const authjwt = require("./authjwt")
const verifySingUp = require("./verifySignUp")

module.exports = {
    authjwt,
    verifySingUp
}